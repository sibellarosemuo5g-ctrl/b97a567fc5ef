// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("config matrix"); }
int main(){
  announce();
  return lionss_run_workload("config-matrix");
}
