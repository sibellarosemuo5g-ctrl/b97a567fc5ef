// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("transitive deps\n", stdout);
  return lionss_run_workload("transitive-deps");
}
