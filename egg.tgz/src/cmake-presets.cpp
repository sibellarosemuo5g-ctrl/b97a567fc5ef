// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("cmake presets"); }
int main(){
  announce();
  return lionss_run_workload("cmake-presets");
}
